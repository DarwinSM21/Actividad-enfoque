﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Progrm_enfoque
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("   --------------------------------------");
            Console.WriteLine("   | Calcular el volumen de un cilindro |");
            Console.WriteLine("   --------------------------------------");

            // Solicita al usuario el radio del cilindro
            Console.Write("Ingrese el radio del cilindro: ");
            double radio;
            while (!double.TryParse(Console.ReadLine(), out radio) || radio <= 0)
            {
                Console.WriteLine("El valor ingresado debe ser un número positivo. Inténtelo de nuevo.");
                Console.Write("Ingrese el radio del cilindro: ");
            }

            // Solicita al usuario la altura del cilindro
            Console.Write("Ingrese la altura del cilindro: ");
            double altura;
            while (!double.TryParse(Console.ReadLine(), out altura) || altura <= 0)
            {
                Console.WriteLine("El valor ingresado debe ser un número positivo. Inténtelo de nuevo.");
                Console.Write("Ingrese la altura del cilindro: ");
            }

            // Calcula el volumen del cilindro
            double volumen = Math.PI * Math.Pow(radio, 2) * altura;

            // Mostrar el resultado
            Console.WriteLine($"El volumen del cilindro con radio {radio} y altura {altura} es: {volumen}");

            Console.ReadKey();
        }
    }
}
